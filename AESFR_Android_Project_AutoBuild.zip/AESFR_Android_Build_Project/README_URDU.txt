AESFR APK بنانے کا آسان طریقہ (یہ ZIP سورس پروجیکٹ ہے، APK ابھی نہیں)

آپ کوڈنگ نہ کریں؛ یہ اقدامات صرف APK بنوانے کے لیے ہیں:
1) اس ZIP کو اپنے Google Drive میں محفوظ کریں اور کسی کمپیوٹر پر extract کریں۔
2) GitHub.com پر اکاؤنٹ بنائیں/لاگ اِن کریں۔
3) New repository بنائیں، نام AESFR رکھیں۔
4) اس فولڈر کے اندر کی فائلیں GitHub repository میں upload کریں (ZIP کو repository میں بطور ایک فائل نہ رکھیں؛ پہلے extract کریں)۔
5) GitHub میں Actions ٹیب کھولیں، "Build AESFR APK" منتخب کریں، Run workflow دبائیں۔
6) Build مکمل ہونے کے بعد run کھولیں، نیچے Artifacts سے AESFR-debug-APK ڈاؤن لوڈ کریں۔
7) ZIP artifact کو extract کریں؛ app-debug.apk فون میں منتقل کرکے انسٹال کریں۔ فون پوچھے تو صرف اپنی بنائی ہوئی APK کے لیے install permission دیں۔

اگر آپ کے پاس کمپیوٹر نہیں ہے تو GitHub پر یہ مراحل فون سے کرنا مشکل ہو سکتا ہے؛ کسی قابل اعتماد شخص سے صرف repository upload اور workflow run کروائیں۔
اس APK میں بنیادی ویب ایپ شامل ہے۔ حقیقی AI/Gemini جواب، بیماری کی تصویر کا AI تجزیہ، خودکار اسکیم اپڈیٹس اور push notifications ابھی فعال نہیں ہیں۔
